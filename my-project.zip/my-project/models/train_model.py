import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow import keras
from keras.models import Sequential
from keras.layers import Dense
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# Load dataset
file_path = ("P:\my-project\data\dataset.csv")
data = pd.read_csv(file_path)

# Fix column names (strip spaces)
data.columns = data.columns.str.strip()

# Check dataset columns
print("Dataset Columns:", data.columns.tolist())

# Use "Benign" as the label column
if 'Benign' not in data.columns:
    raise ValueError("Error: 'Benign' column not found in dataset.")

# Drop non-numeric columns
drop_cols = ['FileName', 'md5Hash', 'BitcoinAddresses']
data = data.drop(columns=[col for col in drop_cols if col in data.columns])

# Rename label column
data.rename(columns={'Benign': 'label'}, inplace=True)

# Convert label: 1 (benign) → 0 (ransomware), 0 (ransomware) → 1 (benign)
data['label'] = 1 - data['label']

# Separate features (X) and labels (y)
X = data.drop(columns=['label'])
y = data['label']

# Normalize data
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Split into train & test sets
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Build Neural Network Model
model = Sequential([
    Dense(64, activation='relu', input_shape=(X_train.shape[1],)),
    Dense(32, activation='relu'),
    Dense(1, activation='sigmoid')
])

# Compile model
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# Train model
model.fit(X_train, y_train, epochs=50, batch_size=32, validation_data=(X_test, y_test))

# Save model & scaler
model.save("ransomware_model.h5")
import joblib
joblib.dump(scaler, "scaler.pkl")

print("✅ Model training complete. Model saved as 'ransomware_model.h5'.")
