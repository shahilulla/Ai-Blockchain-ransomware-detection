import os
import shutil
import tkinter as tk
from tkinter import scrolledtext
import threading
import tensorflow as tf
import watchdog.events
import watchdog.observers
import joblib
import numpy as np
import pandas as pd
import logging
from config import Config, MONITOR_PATHS

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ✅ Verified Resource Loading
try:
    model = tf.keras.models.load_model(Config.MODEL_PATH)
    scaler = joblib.load(Config.SCALER_PATH)  # Now properly defined
except Exception as e:
    logger.critical(f"System initialization failed: {str(e)}")
    raise SystemExit("Critical failure during startup")

class FileEventHandler(watchdog.events.FileSystemEventHandler):
    def __init__(self, app):
        self.app = app

    def on_created(self, event):
        if not event.is_directory:
            self.app.process_file(event.src_path, "Created")

    def on_modified(self, event):
        if not event.is_directory:
            self.app.process_file(event.src_path, "Modified")

class SecurityMonitorApp:
    def __init__(self, root):
        self.root = root
        root.title("Enterprise Security Monitor")
        root.geometry("800x600")

        # Interface Components
        self.console = scrolledtext.ScrolledText(root, wrap=tk.WORD, state=tk.DISABLED)
        self.console.pack(pady=10, fill=tk.BOTH, expand=True)

        self.status = tk.Label(root, text="System Secure", fg="green", font=("Arial", 14))
        self.status.pack(pady=5)

        control_frame = tk.Frame(root)
        control_frame.pack(pady=10)
        
        self.start_btn = tk.Button(control_frame, text="Activate Protection", 
                                 command=self.start_protection)
        self.start_btn.pack(side=tk.LEFT, padx=5)
        
        self.stop_btn = tk.Button(control_frame, text="Deactivate Protection", 
                                command=self.stop_protection, state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=5)

        self.observers = []

    def log_message(self, text, is_threat=False):
        def update_display():
            self.console.config(state=tk.NORMAL)
            self.console.insert(tk.END, f"{text}\n")
            self.console.yview(tk.END)
            self.console.config(state=tk.DISABLED)
            self.status.config(
                text="THREAT DETECTED" if is_threat else "SYSTEM SECURE",
                fg="red" if is_threat else "green"
            )
        self.root.after(0, update_display)
        logger.info(text)

    def analyze_file(self, file_path):
        try:
            # Feature Extraction
            file_size = os.path.getsize(file_path)
            entropy = self.calculate_entropy(file_path)
            
            # Model Prediction
            features = pd.DataFrame([[file_size, entropy]], 
                                  columns=["file_size", "entropy"])
            scaled_features = scaler.transform(features)
            prediction = model.predict(scaled_features, verbose=0)[0][0]
            
            return prediction > 0.5
        except Exception as e:
            logger.error(f"Analysis failed: {file_path} - {str(e)}")
            return False

    def calculate_entropy(self, path):
        try:
            with open(path, "rb") as f:
                data = f.read()
                if len(data) == 0:
                    return 0.0
                probabilities = np.bincount(list(data), minlength=256) / len(data)
                return -np.sum(probabilities * np.log2(probabilities + 1e-10))
        except Exception as e:
            logger.error(f"Entropy calculation failed: {path} - {str(e)}")
            return 0.0

    def quarantine_file(self, original_path):
        try:
            filename = os.path.basename(original_path)
            target_path = os.path.join(Config.QUARANTINE_PATH, filename)
            
            # Handle duplicates
            if os.path.exists(target_path):
                base, ext = os.path.splitext(filename)
                counter = 1
                while os.path.exists(os.path.join(Config.QUARANTINE_PATH, f"{base}_{counter}{ext}")):
                    counter += 1
                target_path = os.path.join(Config.QUARANTINE_PATH, f"{base}_{counter}{ext}")
            
            shutil.move(original_path, target_path)
            self.log_message(f"Quarantined: {original_path} → {target_path}", is_threat=True)
        except Exception as e:
            self.log_message(f"Quarantine failed: {original_path} - {str(e)}", is_threat=True)

    def start_protection(self):
        self.observers.clear()
        for drive in MONITOR_PATHS:
            if os.path.exists(drive):
                observer = watchdog.observers.Observer()
                handler = FileEventHandler(self)
                observer.schedule(handler, drive, recursive=True)
                observer.start()
                self.observers.append(observer)
        
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.log_message("Protection system activated")

    def stop_protection(self):
        for observer in self.observers:
            observer.stop()
            observer.join()
        self.observers.clear()
        
        self.start_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        self.log_message("Protection system deactivated")

    def process_file(self, path, action):
        try:
            if self.analyze_file(path):
                self.log_message(f"Ransomware detected: {path}", is_threat=True)
                self.quarantine_file(path)
            else:
                self.log_message(f"Secure file: {path}")
        except Exception as e:
            self.log_message(f"Processing error: {path} - {str(e)}")

if __name__ == "__main__":
    root = tk.Tk()
    app = SecurityMonitorApp(root)
    root.mainloop()