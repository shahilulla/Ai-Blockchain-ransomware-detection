from flask import Flask, request, jsonify
from flask_cors import CORS  # For handling CORS
from flask_limiter import Limiter  # For rate limiting
from flask_limiter.util import get_remote_address
import json
import datetime
import os
import logging

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Rate Limiting
limiter = Limiter(
    app=app,
    key_func=get_remote_address,  # Limit by client IP address
    default_limits=["200 per day", "50 per hour"]  # Default rate limits
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Environment Variables
BLOCKCHAIN_LOG_FILE = os.getenv("BLOCKCHAIN_LOG_FILE", "blockchain_logs.json")
PORT = int(os.getenv("PORT", 5000))

# ✅ Function to load blockchain logs
def load_blockchain():
    """Load blockchain logs from the JSON file."""
    if os.path.exists(BLOCKCHAIN_LOG_FILE):
        try:
            with open(BLOCKCHAIN_LOG_FILE, "r") as file:
                return json.load(file)
        except (json.JSONDecodeError, IOError) as e:
            logger.error(f"Error loading blockchain logs: {e}")
            return []
    return []

# ✅ Function to save blockchain logs
def save_blockchain(data):
    """Save blockchain logs to the JSON file."""
    try:
        with open(BLOCKCHAIN_LOG_FILE, "w") as file:
            json.dump(data, file, indent=4)
    except IOError as e:
        logger.error(f"Error saving blockchain logs: {e}")

# ✅ Home Route
@app.route('/')
def home():
    """Home route to check if the API is running."""
    return jsonify({"message": "Ransomware Detection API is running!"}), 200

# ✅ Log Ransomware Detection
@app.route('/log_ransomware', methods=['POST'])
@limiter.limit("10 per minute")  # Rate limit for this route
def log_ransomware():
    """Log ransomware detection details."""
    try:
        data = request.json
        if not data:
            return jsonify({"error": "No data provided"}), 400

        # Validate required fields
        required_fields = ["FileName", "md5Hash"]
        for field in required_fields:
            if field not in data:
                return jsonify({"error": f"Missing required field: {field}"}), 400

        # Add timestamp and unique log ID
        log_entry = {
            "log_id": len(load_blockchain()) + 1,
            "FileName": data["FileName"],
            "md5Hash": data["md5Hash"],
            "timestamp": datetime.datetime.now().isoformat(),
            "details": data
        }

        # Save to blockchain (Immutable Log)
        blockchain_data = load_blockchain()
        blockchain_data.append(log_entry)
        save_blockchain(blockchain_data)

        logger.info(f"✅ Ransomware Detected & Logged: {log_entry}")
        return jsonify({"status": "success", "log_id": log_entry["log_id"]}), 200

    except Exception as e:
        logger.error(f"Error logging ransomware: {e}")
        return jsonify({"error": "Internal server error"}), 500

# ✅ View Blockchain Logs (For Debugging)
@app.route('/view_logs', methods=['GET'])
def view_logs():
    """View all blockchain logs."""
    try:
        blockchain_data = load_blockchain()
        return jsonify(blockchain_data), 200
    except Exception as e:
        logger.error(f"Error viewing logs: {e}")
        return jsonify({"error": "Internal server error"}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=PORT, debug=False)  # Disable debug mode in production