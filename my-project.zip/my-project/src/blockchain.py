import hashlib
import json
import time
import hmac
import os

# Secret key for HMAC (should be stored securely)
SECRET_KEY = b'super_secure_key'

# Blockchain storage file
BLOCKCHAIN_FILE = "blockchain.json"

# Load existing blockchain (if available)
blockchain = []

if os.path.exists(BLOCKCHAIN_FILE):
    with open(BLOCKCHAIN_FILE, "r") as f:
        try:
            blockchain = json.load(f)
        except json.JSONDecodeError:
            print("⚠️ Blockchain file corrupted. Starting fresh.")

# Generate a block hash with HMAC authentication
def generate_hash(block):
    block_string = json.dumps(block, sort_keys=True).encode()
    return hmac.new(SECRET_KEY, block_string, hashlib.sha256).hexdigest()

# Create a new block
def create_block(previous_hash, log_entry, severity="INFO"):
    block = {
        'index': len(blockchain) + 1,
        'timestamp': time.time(),
        'log_entry': log_entry,
        'severity': severity,  # Added severity level (INFO, WARNING, CRITICAL)
        'previous_hash': previous_hash
    }
    block['hash'] = generate_hash(block)
    return block

# Add a new log entry to the blockchain
def add_log(log_entry, severity="INFO"):
    previous_hash = blockchain[-1]['hash'] if blockchain else "0"
    block = create_block(previous_hash, log_entry, severity)
    blockchain.append(block)

    # Save blockchain to file
    with open(BLOCKCHAIN_FILE, "w") as f:
        json.dump(blockchain, f, indent=4)

    print(f"✅ New log added: {block['log_entry']} (Severity: {block['severity']})")

# Verify blockchain integrity
def verify_blockchain():
    print("\n🔍 Verifying Blockchain Integrity...")
    for i in range(1, len(blockchain)):
        prev_hash = blockchain[i - 1]['hash']
        expected_hash = generate_hash({
            'index': blockchain[i]['index'],
            'timestamp': blockchain[i]['timestamp'],
            'log_entry': blockchain[i]['log_entry'],
            'severity': blockchain[i]['severity'],
            'previous_hash': prev_hash
        })
        
        if blockchain[i]['previous_hash'] != prev_hash or blockchain[i]['hash'] != expected_hash:
            print(f"❌ Tampering detected at Block {i + 1}!")
            return False

    print("✅ Blockchain is valid!")
    return True

# Search logs by keyword or severity
def search_logs(keyword=None, severity=None):
    print("\n🔎 Searching logs...")
    results = []
    
    for block in blockchain:
        if (keyword and keyword.lower() in block['log_entry'].lower()) or (severity and block['severity'] == severity):
            results.append(block)
    
    if results:
        for log in results:
            print(f"[{log['severity']}] {log['log_entry']} (Time: {time.ctime(log['timestamp'])})")
    else:
        print("No matching logs found.")

# Example usage
if __name__ == "__main__":
    add_log("System started", severity="INFO")
    add_log("Suspicious activity detected", severity="WARNING")
    add_log("Ransomware attack detected!", severity="CRITICAL")

    verify_blockchain()  # Check integrity
    search_logs(keyword="attack")  # Search logs by keyword
    search_logs(severity="CRITICAL")  # Search logs by severity
