import os
import logging
from dotenv import load_dotenv  # For loading environment variables from a .env file

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load environment variables from .env file (if present)
load_dotenv()

# ✅ Configuration Class
class Config:
    # Flask API URL
    FLASK_API_URL = os.getenv("FLASK_API_URL", "http://localhost:5000/log_ransomware")

    # Blockchain API URL
    BLOCKCHAIN_API_URL = os.getenv("BLOCKCHAIN_API_URL", "http://localhost:5001/store_log")

    # Path to the ransomware detection model
    MODEL_PATH = os.getenv("MODEL_PATH", "ransomware_model.h5")

    # Validate critical configurations
    @classmethod
    def validate(cls):
        """Validate critical configurations."""
        if not os.path.exists(cls.MODEL_PATH):
            logger.warning(f"Model file not found at: {cls.MODEL_PATH}")

        if not cls.FLASK_API_URL.startswith(("http://", "https://")):
            logger.warning(f"Invalid FLASK_API_URL: {cls.FLASK_API_URL}")

        if not cls.BLOCKCHAIN_API_URL.startswith(("http://", "https://")):
            logger.warning(f"Invalid BLOCKCHAIN_API_URL: {cls.BLOCKCHAIN_API_URL}")

# ✅ Function to get available drives
def get_available_drives():
    """Get a list of available drives on the system."""
    drives = [f"{drive}:/" for drive in "ABCDEFGHIJKLMNOPQRSTUVWXYZ" if os.path.exists(f"{drive}:/")]
    logger.info(f"Available drives: {drives}")
    return drives

# ✅ Monitor Paths
MONITOR_PATHS = get_available_drives()

# Validate configurations on import
Config.validate()