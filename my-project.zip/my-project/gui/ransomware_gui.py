import os
import shutil
import tkinter as tk
from tkinter import scrolledtext, ttk
import threading
import tensorflow as tf
import watchdog.events
import watchdog.observers
import joblib
import pandas as pd
import pefile

# Load AI Model and Scaler
MODEL_PATH = "p:/my-project/ransomware_model.h5"
SCALER_PATH = "p:/my-project/scaler.pkl"

try:
    model = tf.keras.models.load_model(MODEL_PATH)
    scaler = joblib.load(SCALER_PATH)
except Exception as e:
    print(f"⚠️ Error loading AI model: {e}")

# Function to Get All Available Drives
def get_available_drives():
    return [f"{drive}:/" for drive in "ABCDEFGHIJKLMNOPQRSTUVWXYZ" if os.path.exists(f"{drive}:/")]

MONITOR_PATHS = get_available_drives()
QUARANTINE_PATH = "p:/Ransomware_Quarantine"
LOG_FILE = "p:/my-project/blockchain_logs.txt"
os.makedirs(QUARANTINE_PATH, exist_ok=True)

# Event Handler for File Monitoring
class MonitorHandler(watchdog.events.FileSystemEventHandler):
    def __init__(self, app):
        self.app = app

    def on_created(self, event):
        if not event.is_directory:
            self.app.process_event(event.src_path, "Created")

    def on_modified(self, event):
        if not event.is_directory:
            self.app.process_event(event.src_path, "Modified")

# Main Antivirus Application
class AntivirusApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Advanced Ransomware Protection")
        self.root.geometry("900x550")

        # Theme and Auto-Monitor Toggles
        self.dark_mode = tk.BooleanVar(value=False)
        self.auto_monitor = tk.BooleanVar(value=False)

        # Notebook Tabs
        self.notebook = ttk.Notebook(root)
        self.home_tab = ttk.Frame(self.notebook)
        self.settings_tab = ttk.Frame(self.notebook)
        self.logs_tab = ttk.Frame(self.notebook)

        self.notebook.add(self.home_tab, text="Home")
        self.notebook.add(self.settings_tab, text="Settings")
        self.notebook.add(self.logs_tab, text="Logs")
        self.notebook.pack(fill=tk.BOTH, expand=True)

        # Initialize UI Components
        self.setup_home()
        self.setup_settings()
        self.setup_logs()

        # Observers for File Monitoring
        self.observers = []

    def setup_home(self):
        ttk.Label(self.home_tab, text="Real-Time Threat Monitoring", font=("Arial", 14)).pack(pady=10)

        self.text_area = scrolledtext.ScrolledText(self.home_tab, wrap=tk.WORD, width=90, height=15, state=tk.DISABLED)
        self.text_area.pack(pady=10)

        self.start_button = ttk.Button(self.home_tab, text="▶ Start Monitoring", command=self.start_monitoring)
        self.start_button.pack(pady=5)

        self.stop_button = ttk.Button(self.home_tab, text="⏹ Stop Monitoring", command=self.stop_monitoring, state=tk.DISABLED)
        self.stop_button.pack(pady=5)

    def setup_settings(self):
        ttk.Label(self.settings_tab, text="Settings", font=("Arial", 14)).pack(pady=10)
        ttk.Checkbutton(self.settings_tab, text="Enable Auto Monitor", variable=self.auto_monitor, command=self.toggle_auto_monitor).pack(pady=5)
        ttk.Checkbutton(self.settings_tab, text="Enable Dark Theme", variable=self.dark_mode, command=self.toggle_theme).pack(pady=5)

    def setup_logs(self):
        ttk.Label(self.logs_tab, text="Logs", font=("Arial", 14)).pack(pady=10)
        self.log_display = scrolledtext.ScrolledText(self.logs_tab, wrap=tk.WORD, width=90, height=15, state=tk.DISABLED)
        self.log_display.pack(pady=10)

    def log_event(self, message):
        formatted_message = f"[LOG] {message}"
        with open(LOG_FILE, "a", encoding="utf-8") as log_file:
            log_file.write(formatted_message + "\n")
        
        # Update GUI logs on the main thread
        self.root.after(100, lambda: self.update_log_display(formatted_message))

    def update_log_display(self, message):
        self.text_area.config(state=tk.NORMAL)
        self.text_area.insert(tk.END, message + "\n")
        self.text_area.yview(tk.END)
        self.text_area.config(state=tk.DISABLED)

        self.log_display.config(state=tk.NORMAL)
        self.log_display.insert(tk.END, message + "\n")
        self.log_display.yview(tk.END)
        self.log_display.config(state=tk.DISABLED)

    def process_event(self, file_path, action):
        try:
            # Normalize file path
            file_path = os.path.normpath(file_path)

            # Scan all files (remove the executable check)
            result = self.check_file_safety(file_path)
            log_message = f"[SCAN] {file_path} {action}. Status: {result}"
            self.log_event(log_message)

            if result == "Threat":
                self.quarantine_file(file_path)

        except Exception as e:
            self.log_event(f"[ERROR] Failed to process {file_path}: {str(e)}")

    def check_file_safety(self, file_path):
        try:
            # Skip PE file parsing for non-executables
            if not file_path.lower().endswith(('.exe', '.dll', '.sys')):
                return "Safe (Non-executable)"

            # Parse PE file headers
            pe = pefile.PE(file_path)
            
            # Extract all features expected by the model
            features = {
                "ExportRVA": pe.OPTIONAL_HEADER.DATA_DIRECTORY[0].VirtualAddress,
                "ExportSize": pe.OPTIONAL_HEADER.DATA_DIRECTORY[0].Size,
                "IatRVA": pe.OPTIONAL_HEADER.DATA_DIRECTORY[12].VirtualAddress,
                "Machine": pe.FILE_HEADER.Machine,
                "MajorImageVersion": pe.OPTIONAL_HEADER.MajorImageVersion,
                "DebugRVA": pe.OPTIONAL_HEADER.DATA_DIRECTORY[6].VirtualAddress,
                "DebugSize": pe.OPTIONAL_HEADER.DATA_DIRECTORY[6].Size,
                "DllCharacteristics": pe.OPTIONAL_HEADER.DllCharacteristics,
                # Add other features used during training
            }
            
            # Convert to DataFrame and scale
            features_df = pd.DataFrame([features])
            scaled_features = scaler.transform(features_df)
            prediction = model.predict(scaled_features)[0][0]
            return "Threat" if prediction > 0.5 else "Safe"

        except pefile.PEFormatError:
            return "Safe (Invalid PE File)"
        except Exception as e:
            return f"Unknown ({str(e)})"

    def quarantine_file(self, file_path):
        try:
            if os.path.exists(file_path):
                filename = os.path.basename(file_path)
                quarantine_path = os.path.join(QUARANTINE_PATH, filename)

                # Handle duplicate filenames
                if os.path.exists(quarantine_path):
                    base, ext = os.path.splitext(filename)
                    counter = 1
                    while os.path.exists(os.path.join(QUARANTINE_PATH, f"{base}_{counter}{ext}")):
                        counter += 1
                    quarantine_path = os.path.join(QUARANTINE_PATH, f"{base}_{counter}{ext}")

                shutil.move(file_path, quarantine_path)
                self.log_event(f"[QUARANTINE] Moved {file_path} to {quarantine_path}")

        except Exception as e:
            self.log_event(f"[ERROR] Quarantine failed for {file_path}: {str(e)}")

    def start_monitoring(self):
        self.observers.clear()

        for drive in MONITOR_PATHS:
            if os.path.exists(drive):
                observer = watchdog.observers.Observer()
                event_handler = MonitorHandler(self)
                observer.schedule(event_handler, path=drive, recursive=True)
                observer.start()
                self.observers.append(observer)

        self.start_button.config(state=tk.DISABLED)
        self.stop_button.config(state=tk.NORMAL)
        self.log_event(f"✅ Monitoring started on drives: {', '.join(MONITOR_PATHS)}")

    def stop_monitoring(self):
        def stop_observers():
            for observer in self.observers:
                observer.stop()
                observer.join()
            self.observers.clear()
            self.root.after(0, self.update_ui_after_stop)

        threading.Thread(target=stop_observers, daemon=True).start()

    def update_ui_after_stop(self):
        self.start_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
        self.log_event("⏹ Monitoring stopped.")

    def toggle_theme(self):
        theme = "dark" if self.dark_mode.get() else "light"
        self.root.tk.call("set_theme", theme)

    def toggle_auto_monitor(self):
        if self.auto_monitor.get():
            self.start_monitoring()
        else:
            self.stop_monitoring()

if __name__ == "__main__":
    root = tk.Tk()
    app = AntivirusApp(root)
    root.mainloop()